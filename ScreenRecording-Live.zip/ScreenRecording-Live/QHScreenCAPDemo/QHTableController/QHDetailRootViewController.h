//
//  QHDetailRootViewController.h
//  QHTableDemo
//
//  Created by chen on 17/3/13.
//  Copyright © 2017年 chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QHDetailRootViewController : UIViewController

@property (nonatomic, strong) NSString *titleString;

@end
